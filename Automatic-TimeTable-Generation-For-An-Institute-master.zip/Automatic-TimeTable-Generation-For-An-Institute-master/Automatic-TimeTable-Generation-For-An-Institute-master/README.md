# TimeTable
Automatic time table generation system.

1)install Xampp server from https://www.apachefriends.org/download.html

2)After installation put the whole downloaded tt folder to htdocs folder of Xampp server.

3)start Xampp server using this command $ sudo /opt/lampp/lampp start.

4)go to browser and paste http://localhost/phpmyadmin/

5)create new database named as "timetable".

6)import timetable.sql(which was inside tt folder) into your newly created database timetable.

7)now run http://localhost/tt/Admin/index.php.

