gcc color_generator.c
./a.out
gcc tt_1.c
./a.out
gcc tt_2.c 
./a.out
