<?php
$output = shell_exec('run.sh');
echo $output;
?>
