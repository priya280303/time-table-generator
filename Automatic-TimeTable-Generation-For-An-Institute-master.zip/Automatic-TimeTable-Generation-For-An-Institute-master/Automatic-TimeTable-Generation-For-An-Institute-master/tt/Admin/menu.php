<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>   
              <!--  <li><a href="faculty_details.php">Faculty<span class="tab-l"></span><span class="tab-r"></span></a></li>   -->
				<li><a href="course_detail.php">Course Details<span class="tab-l"></span><span class="tab-r"></span></a></li>
	     		<li><a href="room_detail.php">Room Details<span class="tab-l"></span><span class="tab-r"></span></a></li> 
                <li><a href="slot_details.php">Slots Details<span class="tab-l"></span><span class="tab-r"></span></a></li>  
                <li><a href="select_course.php">Select Courses<span class="tab-l"></span><span class="tab-r"></span></a></li> 								
              <li><a href="Logout.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>      
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->
